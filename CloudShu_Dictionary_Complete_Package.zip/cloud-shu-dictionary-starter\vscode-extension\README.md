# Cloud Shu Dictionary (云舒字典) - VS Code Extension

把中文汉字变成可执行的代码技能。
Turn Chinese characters into executable code skills directly in your editor.

## Features (功能)

- **Semantic Execution**: Select text (JSON/String) and run a character skill like `bian` (变) to transform it.
- **Native Integration**: Works seamlessly with your local `.trae/skills/dictionary` repository.
- **Extensible**: Add new characters as Python scripts, and they instantly appear in the command palette.

## Requirements (依赖)

1.  **Python 3.x**: Ensure `python` is in your PATH.
2.  **Dependencies**: Run the dependency manager script to install required packages for all skills.

    ```bash
    # Run from project root
    python .trae/skills/dictionary/manage_dependencies.py --install
    ```

## Usage (使用方法)

1.  Open your project workspace in VS Code.
2.  Ensure your project has the `.trae/skills/dictionary` folder structure.
3.  Select any text in the editor (or place cursor on an empty line).
    - Example: Select a JSON object `{ "name": "Cloud Shu" }`.
4.  Open Command Palette (`Ctrl+Shift+P` or `Cmd+Shift+P`).
5.  Run `Dictionary: Execute Skill`.
6.  Select a skill from the list (e.g., `bian`).
7.  The selected text will be replaced by the skill's output.

### Creating New Skills (创建新技能)

1.  Run `Dictionary: Create New Skill` from the Command Palette.
2.  Fill in the form (ID, Display Name, Type, Description).
3.  Click **Generate Skill**.
4.  A new folder with `main.py` and `SKILL.md` will be created automatically.
5.  Start coding your magic!

## Configuration (配置)

- `dictionary.pythonPath`: Path to your Python interpreter (default: `python`).

## Development & Testing (开发与测试)

### 1. Mock Testing (无需启动插件)
Run the Python test runner to verify skill logic:

```bash
# Run from project root
python .trae/skills/dictionary/test_runner.py
```

### 2. Extension Debugging (启动插件)
1.  Open the `vscode-extension` folder in VS Code.
2.  Install dependencies:
    ```bash
    npm install
    ```
3.  Press `F5` to launch a new Extension Development Host window.
4.  **Crucial Step**: In the new window, open the root folder `e:\traework\000 商业化字典技能` (or any workspace containing `.trae/skills/dictionary`).
5.  Test the commands.
