import os
import json
import subprocess
import sys

def test_skill(skill_name, input_data):
    print(f"\n--- Testing Skill: {skill_name} ---")
    
    # 1. Locate the skill script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    # Assuming this script is in .trae/skills/dictionary/
    if skill_name == "bian":
        script_path = os.path.join(base_dir, "characters", "bian", "main.py")
    elif skill_name == "ri-xin-yue-yi":
        script_path = os.path.join(base_dir, "idioms", "ri-xin-yue-yi", "main.py")
    else:
        print(f"Unknown skill: {skill_name}")
        return

    if not os.path.exists(script_path):
        print(f"Script not found: {script_path}")
        return

    # 2. Prepare input
    input_str = json.dumps(input_data)
    
    # 3. Execute
    try:
        # Use the same execution logic as the plugin
        cmd = [sys.executable, script_path, input_str]
        print(f"Executing: {' '.join(cmd)}")
        
        result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8')
        
        if result.returncode != 0:
            print("Error (Stderr):")
            print(result.stderr)
        else:
            print("Success (Stdout):")
            try:
                output_json = json.loads(result.stdout)
                print(json.dumps(output_json, indent=2, ensure_ascii=False))
            except json.JSONDecodeError:
                print("Raw Output:", result.stdout)
                
    except Exception as e:
        print(f"Exception: {e}")

if __name__ == "__main__":
    # Test Case 1: bian (Convert JSON to Markdown)
    input_bian = {
        "data": {"name": "Cloud Shu", "role": "AI Assistant", "level": 99},
        "format": "json_to_markdown"
    }
    test_skill("bian", input_bian)
    
    # Test Case 2: ri-xin-yue-yi (Generate GitHub Report)
    # Note: This might take a while due to network search
    input_rixin = {}
    test_skill("ri-xin-yue-yi", input_rixin)
