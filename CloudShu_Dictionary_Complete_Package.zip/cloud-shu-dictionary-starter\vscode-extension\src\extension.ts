import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import { PythonRunner, SkillResult } from './pythonRunner';
import { SkillCreatorPanel } from './skillCreatorPanel';

export function activate(context: vscode.ExtensionContext) {
    console.log('Cloud Shu Dictionary is now active!');

    // Command 1: Execute Skill
    const executeDisposable = vscode.commands.registerCommand('dictionary.execute', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No active editor found.');
            return;
        }

        const workspaceFolders = vscode.workspace.workspaceFolders;
        if (!workspaceFolders) {
            vscode.window.showErrorMessage('Please open a workspace containing the dictionary skills.');
            return;
        }

        const rootPath = workspaceFolders[0].uri.fsPath;
        const dictPath = path.join(rootPath, '.trae', 'skills', 'dictionary');
        
        if (!fs.existsSync(dictPath)) {
             vscode.window.showErrorMessage(`Dictionary skills not found at: ${dictPath}`);
             return;
        }

        // Scan for skills (characters and idioms)
        const skills = scanSkills(dictPath);
        if (skills.length === 0) {
            vscode.window.showInformationMessage('No skills found in the dictionary.');
            return;
        }

        // Show QuickPick
        const selected = await vscode.window.showQuickPick(skills, {
            placeHolder: 'Select a skill to execute (e.g., bian, ri-xin-yue-yi)',
            matchOnDescription: true
        });

        if (!selected) return;

        // Get selected text as input
        const selection = editor.selection;
        const text = editor.document.getText(selection);
        
        // Prepare input JSON
        let inputJson = {};
        try {
            // Try to parse as JSON, if fails, treat as raw string in "data" field
            inputJson = JSON.parse(text);
        } catch (e) {
            inputJson = { "data": text };
        }

        // Execute Python Script
        const runner = new PythonRunner();
        try {
             await vscode.window.withProgress({
                location: vscode.ProgressLocation.Notification,
                title: `Executing skill: ${selected.label}...`,
                cancellable: false
            }, async () => {
                // Type assertion since we know it returns Promise<SkillResult>
                const result = await runner.execute(selected.path, inputJson) as any;
                
                // Replace text with result
                if (result.status === 'success') {
                    let output = '';
                    
                    if (typeof result.data === 'string') {
                        output = result.data;
                    } else if (result.data) {
                        // Prioritize specific fields
                        if (result.data.result) output = result.data.result;
                        else if (result.data.report) output = result.data.report;
                        else output = JSON.stringify(result.data, null, 2);
                    } else {
                        output = "Success (No Data)";
                    }
                                   
                    editor.edit((editBuilder: vscode.TextEditorEdit) => {
                        editBuilder.replace(selection, output);
                    });
                } else {
                    vscode.window.showErrorMessage(`Skill Error: ${result.message}`);
                }
            });
        } catch (err: any) {
            vscode.window.showErrorMessage(`Execution Failed: ${err.message}`);
        }
    });

    // Command 2: Create New Skill (GUI)
    const createDisposable = vscode.commands.registerCommand('dictionary.createSkill', () => {
        SkillCreatorPanel.createOrShow(context.extensionUri);
    });

    context.subscriptions.push(executeDisposable, createDisposable);
}

interface SkillItem extends vscode.QuickPickItem {
    path: string;
}

function scanSkills(dictPath: string): SkillItem[] {
    const skills: SkillItem[] = [];
    
    // Scan characters
    const charPath = path.join(dictPath, 'characters');
    if (fs.existsSync(charPath)) {
        fs.readdirSync(charPath).forEach(dir => {
            const mainPy = path.join(charPath, dir, 'main.py');
            if (fs.existsSync(mainPy) && !dir.startsWith('.')) {
                skills.push({ label: dir, description: 'Character', path: mainPy });
            }
        });
    }

    // Scan idioms
    const idiomPath = path.join(dictPath, 'idioms');
    if (fs.existsSync(idiomPath)) {
        fs.readdirSync(idiomPath).forEach(dir => {
            const mainPy = path.join(idiomPath, dir, 'main.py');
            if (fs.existsSync(mainPy) && !dir.startsWith('.')) {
                skills.push({ label: dir, description: 'Idiom', path: mainPy });
            }
        });
    }

    return skills;
}

export function deactivate() {}
