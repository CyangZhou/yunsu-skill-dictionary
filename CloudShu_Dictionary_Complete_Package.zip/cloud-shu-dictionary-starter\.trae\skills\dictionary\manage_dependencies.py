import os
import subprocess
import argparse
import sys

def find_requirements(base_dir):
    reqs = []
    print(f"Scanning for requirements.txt in {base_dir}...")
    for root, dirs, files in os.walk(base_dir):
        # Skip hidden directories like __pycache__ or .git
        if any(part.startswith('.') for part in root.split(os.sep)):
            continue
            
        if "requirements.txt" in files:
            path = os.path.join(root, "requirements.txt")
            print(f"  Found: {path}")
            try:
                with open(path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            reqs.append(line)
            except Exception as e:
                print(f"  Error reading {path}: {e}")
                
    return sorted(list(set(reqs)))

def main():
    parser = argparse.ArgumentParser(description="Dictionary Dependency Manager")
    parser.add_argument("--install", action="store_true", help="Install dependencies using pip")
    parser.add_argument("--output", default="requirements_all.txt", help="Output file name (default: requirements_all.txt)")
    args = parser.parse_args()
    
    base_dir = os.path.dirname(os.path.abspath(__file__))
    all_reqs = find_requirements(base_dir)
    
    if not all_reqs:
        print("No dependencies found.")
        return

    print(f"\nFound {len(all_reqs)} unique dependencies:")
    for req in all_reqs:
        print(f"  - {req}")
    
    output_path = os.path.join(base_dir, args.output)
    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(all_reqs))
        print(f"\nSuccessfully generated: {output_path}")
    except Exception as e:
        print(f"Error writing output file: {e}")
        return
    
    if args.install:
        print("\nInstalling dependencies...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", output_path])
            print("Installation complete.")
        except subprocess.CalledProcessError as e:
            print(f"Installation failed: {e}")
        except Exception as e:
            print(f"An error occurred during installation: {e}")

if __name__ == "__main__":
    main()
