# Cloud Shu Dictionary Starter Kit (云舒字典启动包)

Welcome to your private executable dictionary.
这是属于你个人的“数字魔法书”。

## 🚀 Quick Start (三步走)

1.  **Run Setup**: Double-click `setup.bat`. (双击运行安装脚本)
2.  **Launch**: Open this folder in VS Code and press `F5`. (在 VS Code 打开本目录并按 F5)
3.  **Magic**: In the new window, press `Ctrl+Shift+P` -> `Dictionary: Create New Skill`. (开始造字)

## Structure (目录结构)

- `vscode-extension/`: The IDE plugin source code.
- `.trae/skills/dictionary/`: Your skill repository.
  - `characters/`: Single character skills.
  - `idioms/`: Multi-character idiom skills.

