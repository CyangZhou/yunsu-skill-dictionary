import sys
import json
import os

def execute(params):
    """
    Skill: ni-hao (你好) - Freemium Example
    Description: Demonstrates how to monetize a skill using API Keys.
    """
    name = params.get("name", "User")
    
    # 1. Monetization Check (商业化验证)
    # Check for API Key in params or environment variables
    api_key = params.get("api_key") or os.environ.get("CLOUD_SHU_KEY")
    
    # In a real scenario, you would validate this key against your server
    # API URL: https://api.cloudshu.com/verify
    is_vip = (api_key == "vip-888") # Mock validation
    
    if is_vip:
        # --- VIP Feature (高级功能) ---
        # Call expensive APIs, generate complex reports, etc.
        message = f"👑 VIP GREETING: Welcome back, Commander {name}. Systems are fully operational."
        tier = "Premium"
    else:
        # --- Free Feature (基础功能) ---
        message = f"Hello {name}. (Upgrade to VIP for premium greetings)"
        tier = "Free"

    return {
        "status": "success",
        "data": {
            "message": message,
            "tier": tier,
            "tip": "Set CLOUD_SHU_KEY=vip-888 to unlock VIP mode."
        }
    }

if __name__ == "__main__":
    try:
        if len(sys.argv) > 1:
            params = json.loads(sys.argv[1])
        else:
            params = {}
        print(json.dumps(execute(params), ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False))
