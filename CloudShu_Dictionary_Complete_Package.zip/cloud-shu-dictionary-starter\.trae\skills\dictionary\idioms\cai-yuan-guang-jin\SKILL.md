# Skill: 财源广进 (cai-yuan-guang-jin)

## Description
AI-powered stock analysis and prediction tool. 
Use this skill when the user asks for stock trends, price predictions, or market analysis.

## Parameters
- `symbol` (required): The stock symbol (e.g., "AAPL", "NVDA").
- `period` (optional): Time period for analysis (default: "1mo").
- `api_key` (optional): The VIP access key. If not provided, the tool will attempt to read from the `CLOUD_SHU_KEY` environment variable.

## Usage Example
User: "Analyze NVDA stock."
Agent Action: Call `cai-yuan-guang-jin` with `{"symbol": "NVDA"}`.

## Returns
JSON object containing:
- `current_price`: Real-time price.
- `prediction`: AI forecast (Bullish/Bearish).
- `confidence`: Confidence score.
