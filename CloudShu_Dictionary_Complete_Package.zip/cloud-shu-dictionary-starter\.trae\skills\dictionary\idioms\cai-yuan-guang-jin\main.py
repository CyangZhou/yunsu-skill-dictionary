import sys
import json
import os
import requests

# This is a CLIENT script. The real logic is in the Cloud.
# 这是一个客户端脚本。真正的核心逻辑在云端。

API_URL = "https://your-cloud-backend.vercel.app" # Replace with your real URL

def execute(params):
    """
    Skill: cai-yuan-guang-jin (财源广进)
    Description: AI Stock Analysis (Premium)
    """
    # 1. Get Key
    api_key = params.get("api_key") or os.environ.get("CLOUD_SHU_KEY")
    
    if not api_key:
        return {
            "status": "error",
            "message": "🔒 This skill is locked. Please purchase a VIP Key.",
            "action": "Buy Key at https://cloudshu.com/store"
        }

    # 2. Call Cloud Brain (SaaS)
    # The user CANNOT see the stock analysis logic because it runs on your server.
    # 用户无法看到选股逻辑，因为代码在你的服务器上运行。
    try:
        response = requests.post(
            f"{API_URL}/api",
            json={
                "skill": "cai-yuan-guang-jin",
                "params": params,
                "api_key": api_key
            },
            timeout=10
        )
        
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 401:
            return {"status": "error", "message": "🚫 Invalid API Key."}
        else:
            return {"status": "error", "message": f"Cloud Error: {response.text}"}
            
    except Exception as e:
        return {"status": "error", "message": f"Connection Failed: {str(e)}"}

if __name__ == "__main__":
    try:
        if len(sys.argv) > 1:
            params = json.loads(sys.argv[1])
        else:
            params = {}
        print(json.dumps(execute(params), ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False))
