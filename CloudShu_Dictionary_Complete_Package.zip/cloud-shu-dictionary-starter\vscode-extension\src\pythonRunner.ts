import * as vscode from 'vscode';
import * as cp from 'child_process';

export interface SkillResult {
    status: 'success' | 'error';
    data?: any;
    message?: string;
}

export class PythonRunner {
    private pythonPath: string;

    constructor() {
        const config = vscode.workspace.getConfiguration('dictionary');
        this.pythonPath = config.get<string>('pythonPath') || 'python';
    }

    public execute(scriptPath: string, input: any): Promise<SkillResult> {
        return new Promise((resolve, reject) => {
            const inputStr = JSON.stringify(input);
            // Use python -u for unbuffered output
            const args = [scriptPath, inputStr];
            
            console.log(`Executing: ${this.pythonPath} ${args.join(' ')}`);

            const process = cp.spawn(this.pythonPath, args);
            
            let stdout = '';
            let stderr = '';

            process.stdout.on('data', (data) => {
                stdout += data.toString();
            });

            process.stderr.on('data', (data) => {
                stderr += data.toString();
            });

            process.on('close', (code) => {
                if (code !== 0) {
                    // Try to parse stderr as JSON error
                    try {
                        const errJson = JSON.parse(stderr);
                        resolve(errJson);
                    } catch (e) {
                        reject(new Error(`Process exited with code ${code}. Stderr: ${stderr}`));
                    }
                } else {
                    try {
                        // Try to find the last valid JSON in stdout
                        // Some scripts might print debug info before the JSON result
                        const lines = stdout.trim().split('\n');
                        let jsonResult = null;
                        
                        // Try parsing the whole output first
                        try {
                             jsonResult = JSON.parse(stdout);
                        } catch {
                            // If failed, try the last line
                             jsonResult = JSON.parse(lines[lines.length - 1]);
                        }
                        
                        resolve(jsonResult);
                    } catch (e) {
                        // Fallback: Return raw string if not JSON
                        resolve({ status: 'success', data: stdout.trim() });
                    }
                }
            });

            process.on('error', (err) => {
                reject(err);
            });
        });
    }
}
