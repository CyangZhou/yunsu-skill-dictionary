# Cloud Shu Trae Kit (云舒字典 Trae 原生版)

专为 Trae IDE 打造的技能扩展包。
Make Trae smarter with your private dictionary skills.

## 🚀 How to Use (如何使用)

1.  **Copy Folder (复制文件夹)**:
    - 将本目录下的 `.trae` 文件夹复制到你的项目根目录。
    - Copy the `.trae` folder to your project root.
    - 如果你已有 `.trae` 目录，请合并内容（即把 `skills/dictionary` 放进去）。

2.  **Install Dependencies (安装依赖)**:
    - 打开 Trae 终端，运行：
    ```bash
    python .trae/skills/dictionary/manage_dependencies.py --install
    ```

3.  **Chat with Trae (开始对话)**:
    - 打开 Trae Chat 面板。
    - 输入指令：
      > "请使用 ni-hao 技能向我打招呼"
      > "Use the ni-hao skill to greet me"
    - Trae 会自动识别技能并执行。

## ✨ Create New Skills (如何造字)

1.  进入 `.trae/skills/dictionary/characters/` 目录。
2.  复制 `ni-hao` 文件夹并重命名（例如 `bian`）。
3.  修改 `main.py` 实现你的逻辑。
4.  回到 Chat，告诉 Trae："现在你可以使用 bian 技能了"。

