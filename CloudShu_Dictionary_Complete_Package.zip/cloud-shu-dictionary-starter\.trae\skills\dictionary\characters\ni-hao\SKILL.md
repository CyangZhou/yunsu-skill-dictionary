# Skill: ni-hao (你好)

Description: A simple greeting skill to get you started.
